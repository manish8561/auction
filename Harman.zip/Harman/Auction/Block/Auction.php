<?php
namespace Harman\Auction\Block;
 
class Auction extends \Magento\Framework\View\Element\Template
{
    public function getHelloWorldTxt()
    {
        return 'Hello world!';
    }
}